<!-- Footer Start -->
<footer class="footer bg-default-100 flex items-center py-5">
    <div class="container flex md:justify-between justify-center w-full gap-4">
        <div>
            <script>document.write(new Date().getFullYear())</script> © Smart Home
        </div>
        <div class="md:flex hidden gap-2 item-center md:justify-end">
            Design &amp; Develop by<a href="#" class="text-primary">Canega Technology</a>
        </div>
    </div>
</footer>
<!-- Footer End -->