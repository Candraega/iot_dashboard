
@vite(['resources/css/icons.css', 'resources/css/app.css',])
@vite(['resources/js/app.js'])
