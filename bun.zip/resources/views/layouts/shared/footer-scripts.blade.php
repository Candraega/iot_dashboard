<!-- Plugin Js (Mandatory in All Pages) -->
<!-- <script src="assets/libs/jquery/jquery.min.js"></script>
<script src="assets/libs/preline/preline.js"></script>
<script src="assets/libs/simplebar/simplebar.min.js"></script>
<script src="assets/libs/iconify-icon/iconify-icon.min.js"></script>
<script src="assets/libs/node-waves/waves.min.js"></script> -->

<!-- App Js (Mandatory in All Pages) -->
<!-- <script src="assets/js/app.js"></script> -->


<!-- App js -->

@vite(['resources/js/app.js'])

