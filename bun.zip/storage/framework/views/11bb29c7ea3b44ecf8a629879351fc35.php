<!-- Page Title Start -->
<div class="flex items-center md:justify-between flex-wrap gap-2 mb-5">
    <h4 class="text-default-900 text-lg font-medium"><?php echo e($title); ?></h4>

    <div class="md:flex hidden items-center gap-3 text-sm font-semibold">
        <a href="#" class="text-sm font-medium text-default-700">Home</a>

        <i class="i-tabler-chevron-right text-lg flex-shrink-0 text-default-500 rtl:rotate-180"></i>

        <a href="#" class="text-sm font-medium text-default-700"><?php echo e($subtitle); ?></a>

        <i class="i-tabler-chevron-right text-lg flex-shrink-0 text-default-500 rtl:rotate-180"></i>

        <a href="#" class="text-sm font-medium text-default-700" aria-current="page"><?php echo e($title); ?></a>
    </div>
</div>
<!-- Page Title End --><?php /**PATH E:\Envato\Dashtrap-Laravel_v1.0\Dashtrap-Laravel\resources\views/layouts/shared/page-title.blade.php ENDPATH**/ ?>