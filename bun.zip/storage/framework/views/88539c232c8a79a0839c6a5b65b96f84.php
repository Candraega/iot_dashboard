

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make("layouts.shared/page-title", ["subtitle" => "Apps", "title" => "Chart"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="grid lg:grid-cols-2 gap-6">
    <div class="card">
        <div class="p-6">
            <h4 class="card-title mb-4">Line with Data Labels</h4>

            <div id="line_chart_datalabel" class="apex-charts" dir="ltr"></div>
        </div>
    </div><!--end card-->

    <div class="card">
        <div class="p-6">
            <h4 class="card-title mb-4">Dashed Line</h4>

            <div id="line_chart_dashed" class="apex-charts" dir="ltr"></div>
        </div>
    </div><!--end card-->

    <div class="card">
        <div class="p-6">
            <h4 class="card-title mb-4">Spline Area</h4>

            <div id="spline_area" class="apex-charts" dir="ltr"></div>
        </div>
    </div><!--end card-->

    <div class="card">
        <div class="p-6">
            <h4 class="card-title mb-4">Column Chart</h4>

            <div id="column_chart" class="apex-charts" dir="ltr"></div>
        </div>
    </div><!--end card-->

    <div class="card">
        <div class="p-6">
            <h4 class="card-title mb-4">Column with Data Labels</h4>

            <div id="column_chart_datalabel" class="apex-charts" dir="ltr"></div>
        </div>
    </div><!--end card-->

    <div class="card">
        <div class="p-6">
            <h4 class="card-title mb-4">Bar Chart</h4>

            <div id="bar_chart" class="apex-charts" dir="ltr"></div>
        </div>
    </div><!--end card-->

    <div class="card">
        <div class="p-6">
            <h4 class="card-title mb-4">Line, Column & Area Chart</h4>

            <div id="mixed_chart" class="apex-charts" dir="ltr"></div>
        </div>
    </div><!--end card-->

    <div class="card">
        <div class="p-6">
            <h4 class="card-title mb-4">Radial Chart</h4>

            <div id="radial_chart" class="apex-charts" dir="ltr"></div>
        </div>
    </div><!--end card-->


    <div class="card">
        <div class="p-6">
            <h4 class="card-title mb-4">Pie Chart</h4>

            <div id="pie_chart" class="apex-charts" dir="ltr"></div>
        </div>
    </div>

    <div class="card">
        <div class="p-6">
            <h4 class="card-title mb-4">Donut Chart</h4>

            <div id="donut_chart" class="apex-charts" dir="ltr"></div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/charts-apex.js']); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vertical', ['title' => 'Apex Chart'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Envato\Dashtrap-Laravel_v1.0\Dashtrap-Laravel\resources\views/charts-apex.blade.php ENDPATH**/ ?>