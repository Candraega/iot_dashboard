


<?php $__env->startSection('css'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['node_modules/jsvectormap/dist/css/jsvectormap.min.css']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.shared/page-title', ['subtitle' => 'Admin', 'title' => 'RFID'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="grid xl:grid-cols-4 md:grid-cols-2 gap-5 mb-5">
      

    
    <div class="card">
        <div class="card-body">
            <div class="mb-4">
                <span class="px-1 py-0.5 text-[10px]/[1.25] font-semibold rounded text-success bg-success/20 float-end">
                    Today
                </span>
                <h5 class="card-title truncate">Cards Total</h5>
            </div>
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-3xl font-medium text-default-800"><?php echo e($total); ?></h2>
                <span class="flex items-center">
                    <span class="text-default-400 text-sm">+<?php echo e($todayPercent); ?>%</span>
                    <i class="i-tabler-arrow-up text-success text-base ms-2"></i>
                </span>
            </div>
            <div class="flex w-full h-1.5 bg-default-200 rounded-full overflow-hidden shadow-sm">
                <div class="flex flex-col justify-center rounded-full bg-primary" style="width: <?php echo e($todayPercent); ?>%;"
                    role="progressbar" aria-valuenow="<?php echo e($todayPercent); ?>" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
        </div>
    </div>




    
    <div class="card">
        <div class="card-body">
            <div class="mb-4">
                <span
                    class="px-1 py-0.5 text-[10px]/[1.25] font-semibold rounded text-success bg-success/20 float-end">All
                    Time</span>
                <h5 class="card-title truncate">Daily Visits</h5>
            </div>
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-3xl font-medium text-default-800">60</h2>
                <span class="flex items-center">
                    <span class="text-default-400 text-sm">60%</span>
                    <i class="i-tabler-arrow-up text-success text-base ms-2"></i>
                </span>
            </div>
            <div class="flex w-full h-1.5 bg-default-200 rounded-full overflow-hidden shadow-sm">
                <div class="flex flex-col justify-center rounded-full bg-success" style="width: 60%;" role="progressbar"
                    aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
        </div>
    </div>
</div>




<br>

<div class="card overflow-hidden">
    <div class="card-header">
        <h4 class="card-title">RFID Card List</h4>
    </div>
    <div class="overflow-x-auto custom-scroll">
        <table class="w-full text-sm text-left text-default-500" id="card-table">
            <thead class="text-xs text-default-700 uppercase bg-default-50 border-b">
                <tr>
                    <th class="px-6 py-3">UID</th>
                    <th class="px-6 py-3">Name</th>
                    <th class="px-6 py-3">Phone</th>
                    <th class="px-6 py-3">Status</th>
                    <th class="px-6 py-3">Action</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-default-200">
                <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-default-50" data-uid="<?php echo e($card->uid); ?>">
                        <td class="px-6 py-4"><?php echo e($card->uid); ?></td>

                        
                        <td class="px-6 py-4">
                            <?php if($card->status === 'unknown'): ?>
                                <form action="<?php echo e(url("rfid/{$card->id}/name")); ?>" method="POST" class="flex flex-wrap gap-2">
                                    <?php echo csrf_field(); ?>
                                    <input name="name" class="form-input form-input-sm rounded border px-2 py-1 flex-1"
                                        placeholder="Isi nama" required>
                                    <input name="phone" class="form-input form-input-sm rounded border px-2 py-1 flex-1"
                                        placeholder="No. HP" required>
                                    <button class="btn btn-sm btn-success">Save</button>
                                </form>
                            <?php else: ?>
                                <?php echo e($card->name); ?>

                            <?php endif; ?>
                        </td>

                        
                        <td class="px-6 py-4">
                            <?php echo e($card->status === 'unknown' ? '-' : $card->phone); ?>

                        </td>

                        
                        <td class="px-6 py-4">
                            <span class="badge text-white bg-<?php echo e($card->status === 'unknown' ? 'secondary' : 'success'); ?>">
                                <?php echo e(ucfirst($card->status)); ?>

                            </span>
                        </td>

                        
                        <td class="px-6 py-4">
                            <?php if($card->status !== 'unknown'): ?>
                                <form action="<?php echo e(url("rfid/{$card->id}")); ?>" method="POST" class="flex flex-wrap gap-2 mb-2">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                    <input name="name" value="<?php echo e($card->name); ?>"
                                        class="form-input form-input-sm rounded border px-2 py-1 flex-1" required>
                                    <input name="phone" value="<?php echo e($card->phone); ?>"
                                        class="form-input form-input-sm rounded border px-2 py-1 flex-1" required>
                                    <button class="btn btn-sm btn-warning">Update</button>
                                </form>
                                <form action="<?php echo e(url("rfid/{$card->id}")); ?>" method="POST"
                                    onsubmit="return confirm('Yakin ingin menghapus kartu ini?')" class="inline-block">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<script>
    let knownUIDs = new Set(
        [...document.querySelectorAll('#card-table tbody tr')].map(tr => tr.dataset.uid)
    );

    function renderCardRow(card) {
        const isUnknown = card.status === 'unknown';
        const csrfToken = '<?php echo e(csrf_token()); ?>';

        return `<tr data-uid="${card.uid}">
            <td class="px-6 py-4">${card.uid}</td>
            <td class="px-6 py-4">
                ${isUnknown ? `
                    <form action="/rfid/${card.id}/name" method="POST" class="flex flex-wrap gap-2">
                        <input type="hidden" name="_token" value="${csrfToken}">
                        <input name="name" class="form-input form-input-sm rounded border px-2 py-1 flex-1" placeholder="Isi nama" required>
                        <input name="phone" class="form-input form-input-sm rounded border px-2 py-1 flex-1" placeholder="No. HP" required>
                        <button class="btn btn-sm btn-success">Simpan</button>
                    </form>
                ` : card.name}
            </td>
            <td class="px-6 py-4">${isUnknown ? '-' : (card.phone ?? '-')}</td>
            <td class="px-6 py-4">
                <span class="badge text-white bg-${isUnknown ? 'secondary' : 'success'}">${card.status.charAt(0).toUpperCase() + card.status.slice(1)}</span>
            </td>
            <td class="px-6 py-4">
                ${!isUnknown ? `
                    <form action="/rfid/${card.id}" method="POST" class="flex flex-wrap gap-2 mb-2">
                        <input type="hidden" name="_token" value="${csrfToken}">
                        <input type="hidden" name="_method" value="PUT">
                        <input name="name" value="${card.name}" class="form-input form-input-sm rounded border px-2 py-1 flex-1" required>
                        <input name="phone" value="${card.phone}" class="form-input form-input-sm rounded border px-2 py-1 flex-1" required>
                        <button class="btn btn-sm btn-warning">Update</button>
                    </form>
                    <form action="/rfid/${card.id}" method="POST" onsubmit="return confirm('Yakin ingin menghapus kartu ini?')" class="inline-block">
                        <input type="hidden" name="_token" value="${csrfToken}">
                        <input type="hidden" name="_method" value="DELETE">
                        <button class="btn btn-sm btn-danger">Hapus</button>
                    </form>
                ` : ''}
            </td>
        </tr>`;
    }

    function fetchCards() {
        fetch('/rfid/unknown-cards')
            .then(response => response.json())
            .then(data => {
                const tbody = document.querySelector('#card-table tbody');
                let newCount = 0;

                data.forEach(card => {
                    if (!knownUIDs.has(card.uid)) {
                        tbody.insertAdjacentHTML('afterbegin', renderCardRow(card));
                        knownUIDs.add(card.uid);
                        newCount++;
                    }
                });

                // Update total kartu
                document.getElementById('total-cards').textContent = knownUIDs.size;
            });
    }

    fetchCards(); // initial
    setInterval(fetchCards, 5000); // every 5 seconds
</script>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/dashboard.js']); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vertical', ['title' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Envato\Dashtrap-Laravel_v1.0\Dashtrap-Laravel\resources\views/rfid/index.blade.php ENDPATH**/ ?>