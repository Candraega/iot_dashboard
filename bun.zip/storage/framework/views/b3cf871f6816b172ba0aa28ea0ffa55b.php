<!DOCTYPE html>
<html lang="en"><?php /**PATH E:\Envato\Dashtrap-Laravel_v1.0\Dashtrap-Laravel\resources\views/layouts/shared/main.blade.php ENDPATH**/ ?>