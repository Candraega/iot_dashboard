<!-- Plugin Js (Mandatory in All Pages) -->
<!-- <script src="assets/libs/jquery/jquery.min.js"></script>
<script src="assets/libs/preline/preline.js"></script>
<script src="assets/libs/simplebar/simplebar.min.js"></script>
<script src="assets/libs/iconify-icon/iconify-icon.min.js"></script>
<script src="assets/libs/node-waves/waves.min.js"></script> -->

<!-- App Js (Mandatory in All Pages) -->
<!-- <script src="assets/js/app.js"></script> -->


<!-- App js -->

<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>

<?php /**PATH E:\Envato\Dashtrap-Laravel_v1.0\Dashtrap-Laravel\resources\views/layouts/shared/footer-scripts.blade.php ENDPATH**/ ?>