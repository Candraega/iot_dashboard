
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/icons.css', 'resources/css/app.css',]); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
<?php /**PATH E:\Envato\Dashtrap-Laravel_v1.0\Dashtrap-Laravel\resources\views/layouts/shared/head-css.blade.php ENDPATH**/ ?>